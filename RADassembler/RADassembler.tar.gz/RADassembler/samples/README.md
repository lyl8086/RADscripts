
An example run:
---
Digest_reads: reads containing enzyme cut sites.

Paired_reads: randomly sheared reads (paired-end reads).
```
# RADassembler -i Digest_reads/ -o Assembly_out -s Paired_reads/ -f gzfastq -P PopMap -t 4
```
